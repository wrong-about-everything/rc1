<?php

declare(strict_types=1);

namespace RC\Infrastructure\Dotenv;

class EnvironmentDependentEnvFile implements DotEnv
{
    private $concreteDotEnv;

    public function __construct()
    {

    }

    public function load(): void
    {

    }
}
